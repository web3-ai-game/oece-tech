# 🌍 賽博宇宙觀

地球 Online 記憶向量宇宙的架構設計。

## 📚 文檔列表

1. **20-earth-online-vector-universe.md** - 完整架構文檔 · 用 AI 量化人性
2. **04-zhuge-legion-architecture.md** - 諸葛軍團 · 5 AI Agent MoE 系統

## 🎯 核心概念

- 靈魂向量系統
- 真理與謊言驗證
- 賽博身份檔案
- 多 Agent 協作架構
