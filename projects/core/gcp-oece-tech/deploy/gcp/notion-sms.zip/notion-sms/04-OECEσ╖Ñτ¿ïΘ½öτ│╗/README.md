# ⚙️ OECE Tech 工程體系

OECE Tech 的基礎設施和技術平台。

## 📚 文檔列表

1. **01-oece-tech-framework.md** - OECE Tech 框架總覽
2. **08-oece-tech-orbital-eden.md** - Orbital Eden · 軌道伊甸園
3. **15-oece-tech-geek-hardware.md** - 極客硬件實戰站

## 🎯 技術棧

從軟件到硬件,從雲端到焊接,完整的極客工程體系。
